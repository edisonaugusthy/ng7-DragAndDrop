import { DraggerDirective } from './dragger.directive';

describe('DraggerDirective', () => {
  it('should create an instance', () => {
    const directive = new DraggerDirective();
    expect(directive).toBeTruthy();
  });
});
