import { DropperDirective } from './dropper.directive';

describe('DropperDirective', () => {
  it('should create an instance', () => {
    const directive = new DropperDirective();
    expect(directive).toBeTruthy();
  });
});
